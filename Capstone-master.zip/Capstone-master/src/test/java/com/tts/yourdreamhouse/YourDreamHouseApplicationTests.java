package com.tts.yourdreamhouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YourDreamHouseApplicationTests {

	@Test
	void contextLoads() {
	}

}
