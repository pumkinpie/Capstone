package com.tts.yourdreamhouse.model;


public class YourDreamHouse {
		
		private String answer;

		public String getAnswer() {
			return answer;
		}

		public void setAnswer(String answer) {
			this.answer = answer;
		}
		
}
