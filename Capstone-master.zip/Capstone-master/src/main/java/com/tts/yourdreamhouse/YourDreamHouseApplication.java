package com.tts.yourdreamhouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YourDreamHouseApplication {

	public static void main(String[] args) {
		SpringApplication.run(YourDreamHouseApplication.class, args);
	}
	
}
