package com.tts.yourdreamhouse.service;

import org.springframework.stereotype.Service;

@Service
public class YourDreamHouseService {

}
